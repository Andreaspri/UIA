//
// Created by Nixxen on 08.09.2021.
//

#ifndef WORKSHEET_2_MYSTRING_H
#define WORKSHEET_2_MYSTRING_H

// Function declarations
char *create_string();
int string_length(char*);

#endif //WORKSHEET_2_MYSTRING_H
